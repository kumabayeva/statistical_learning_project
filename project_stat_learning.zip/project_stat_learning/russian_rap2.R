install.packages("tidyverse")  # For data manipulation and visualization
install.packages("readr")      # For reading CSV files
install.packages("caret")      # For easy machine learning workflow
install.packages("corrplot")   # For visualizing correlations

library(tidyverse)
library(readr)
library(caret)
library(corrplot)

dataset <- read_csv("/Users/mad.kum/Desktop/Five_years_of_Russian_Rap_Dataset.csv")

colnames(dataset)
glimpse(dataset)
summary(dataset)

# Checking for missing values
sum(is.na(dataset))

# Using ggplot2 to plot relationships
ggplot(dataset, aes(x=PredictorVariable, y=TargetVariable)) +
  geom_point() +
  geom_smooth(method = "lm")

